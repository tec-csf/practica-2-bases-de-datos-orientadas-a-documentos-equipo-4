from flask import request, url_for, jsonify
from flask_api import FlaskAPI, status, exceptions
from pymongo import MongoClient
from bson.son import SON

app = FlaskAPI(__name__)

@app.route("/")#, methods=['GET'])
def obtener():
    mongo_uri = "mongodb://mongo-router-p2:27017"

    client = MongoClient(mongo_uri)
    db = client.Practica2
    collectionDueno = db.Dueno
    collectionTienda = db.Tienda
    collectionDireccion = db.Direccion

    #Primera consulta, cantidad de personas con nombre "Drake"
    pipe = [{"$match":{"nombre":"Drake"}},{"$group":{"_id":"$nombre","cantidad":{"$sum":1}}},{"$project":{"_id":1,"cantidad":1}},{"$sort": SON([("cantidad", -1), ("_id", -1)])}]

    cursor = collectionDueno.aggregate(pipe)

    result1 = list(cursor)

    #Segunda consulta, cantidad de tiendas con la misma dirección
    pipe = [{"$group":{"_id":"$direccion", "Cantidad":{"$sum":1}}},{"$project":{"_id":1,"Cantidad":1}},{"$sort":{"_id":1}}]
    cursor = collectionTienda.aggregate(pipe)

    result2 = list(cursor)

    #Tercera consulta, cantidad de tiendas en la colonia South Destini
    pipe = [{"$match":{"colonia":"South Destini"}},{"$group":{"_id":"$colonia","Cantidad":{"$sum":1}}},{"$project":{"_id":1,"Cantidad":1}},{"$sort":{"_id":1}}]

    cursor = collectionDireccion.aggregate(pipe)

    result3 = list(cursor)

    return [result1,result2,result3]


if __name__ == "__main__":
    app.run(host="0.0.0.0", debug=True)
